// 1. No access to window/document object
// 2. No access to local/session Storage
// 3. No access to global variables from the main thread
// 4. But access to XMLHttpRequest / indexedDB / fetch api

// console.log(document); // error !

onmessage = function (msgFromMainThread) {
  var largeArray = [];
  for (let i = 0; i < 8000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 5000; j++) {
      largeArray[i][j] = Math.random();
    }
  }

  postMessage(largeArray[3000][3000]);
};
